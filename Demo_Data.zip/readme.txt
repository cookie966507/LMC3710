You have to keep the .exe file int the same directory ad the data folder. I haven't figured out a way to go around this.

Everything should be updated and polished, minus me being picky about some of the icon textures. You can play with a controller where:

-left joystick is to move
-right joystick is to look up or down
-A is to jump

if you don't have a crontroller:
-move with arrow keys
-jump with space

Hinderer:
-Q is snow
-W is pillars
-E is wind

Helper:
-I is speed boost
-O is jump boost
-P is teleport

They all have a visual cooldown timer and different times. Scenery has also been added. However, there is not a way to quit unfortunately.